package com.example.a108590058_7_1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ICActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_icecream);
    }
}