package com.example.a108590058_72;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    private LinkedList<ListMenu> menu;
    private RecyclerView recyclerview;
    private MenuAdapter menu_adap;
    public static final String EXTRA_REPLY = "com.example.recipeassignment.extra.REPLY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        menu = Menus.getRecipes();
        recyclerview = findViewById(R.id.recyclerview);
        menu_adap = new MenuAdapter(this, menu);
        recyclerview.setAdapter(menu_adap);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
    }
}