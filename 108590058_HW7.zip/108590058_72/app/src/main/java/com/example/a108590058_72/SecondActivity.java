package com.example.a108590058_72;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    //Views to bind to
    public String index;
    public TextView textview1;
    public ImageView imageView;
    public TextView textview2;

    /**
     * On Create method for the activity
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Setup our views
        imageView = findViewById(R.id.Image);
        textview1 = findViewById(R.id.Name);
        textview2 = findViewById(R.id.StepsText);

        //Get the data from the intent
        Intent intent = getIntent();
        index = intent.getStringExtra(MainActivity.EXTRA_REPLY);
        loadRecipe(index);
    }

    private void loadRecipe(String index) {
        int pos = Integer.parseInt(index);
        ListMenu menu = Menus.getRecipes().get(pos);
        textview1.setText(menu.name);
        textview2.setText(menu.ingredients + "\n\n" + menu.directions);
        if (menu.name != null) {
            switch (menu.name) {
                case "Best Banana Bread":
                    imageView.setImageResource(R.drawable.image1);
                    break;
                case "Banana Bread by friend":
                    imageView.setImageResource(R.drawable.image2);
                    break;
                case "Banana Bread Raisin by master":
                    imageView.setImageResource(R.drawable.image3);
                    break;
                case "Banana Bread by master":
                    imageView.setImageResource(R.drawable.image4);
                    break;
                case "Banana Bread by jos":
                    imageView.setImageResource(R.drawable.image5);
                    break;
                case "Banana Bread by mom":
                    imageView.setImageResource(R.drawable.image6);
                default:
                    break;
            }
        }

    }
}


