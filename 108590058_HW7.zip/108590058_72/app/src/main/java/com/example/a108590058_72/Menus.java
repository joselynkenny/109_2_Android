package com.example.a108590058_72;
import java.util.LinkedList;

public class Menus {
    static LinkedList<ListMenu> menu;

    static LinkedList<ListMenu> getRecipes() {return menu;}
    static {
        menu = new LinkedList<ListMenu>();
        String name = "Best Banana Bread";
        String description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        String ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        String directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";

        menu.add(new ListMenu(name, description, ingredients, directions));

        name = "Banana Bread by friend";
        description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";
        menu.add(new ListMenu(name, description, ingredients, directions));


        name = "Banana Bread Raisin by friend";
        description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";
        menu.add(new ListMenu(name, description, ingredients, directions));

        name = "Banana Bread by master";
        description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";
        menu.add(new ListMenu(name, description,  ingredients, directions));


        name = "Banana Bread by jos";
        description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";
        menu.add(new ListMenu(name, description, ingredients, directions));



        name = "Banana Bread by mom";
        description = "Serving: 1Slice | Calories: 168kcal | Carbohydrates: 40g | Protein: 4g | Fat: 9g | Saturated Fat: 5g |" +
                " Cholesterol: 55mg | Sodium: 270mg | Potassium: 157mg | Fiber: 2g | Sugar: 21g |" +
                " Vitamin A: 300IU | Vitamin C: 3.3mg | Calcium: 10mg | Iron: 1.3mg" ;
        ingredients = "1 Stick (½ Cup) Butter\n" +
                "3 Large Ripe Bananas\n" +
                "2 Large Eggs\n" +
                "1 teaspoon Vanilla Extract\n" +
                "2 Cups All Purpose Flour\n" +
                "1 Cup Granulated Sugar\n" +
                "1 teaspoon Baking Soda\n" +
                " \n" +
                "½ teaspoon salt\n" +
                "½ teaspoon cinnamon";
        directions = "1. Preheat oven to 350 degrees. Spray a loaf pan with non-stick cooking spray or grease with butter and set aside.\n" +
                "\n2. Add the stick of butter to a large bowl and microwave for 1 minute, or until melted.\n" +
                "\n3. Add the bananas to the same bowl and mash with a fork.\n" +
                "\n4. Add the vanilla extract and egg to the bowl and use the same fork to mash and stir until no yellow streaks of egg remain.\n" +
                "\n5. In a second large bowl whisk together the flour, sugar, baking soda, salt, and cinnamon.\n"+
                "\n6. Add the dry ingredients to the wet ingredients and mix together with a spatula just until combined.\n"+
                "\n7. Pour the batter into prepared loaf pan and bake for 45-55 minutes until a toothpick inserted in the center of the bread comes out clean.";
        menu.add(new ListMenu(name, description, ingredients, directions));



    }
}