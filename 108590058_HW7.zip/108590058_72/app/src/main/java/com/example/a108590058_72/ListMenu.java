package com.example.a108590058_72;

public class ListMenu {
    public ListMenu(String name, String description, String ingredients, String directions) {
        this.name = name;
        this.description = description;
        this.ingredients = ingredients;
        this.directions = directions;
    }

    public String name;
    public String description;
    public String ingredients;
    public String directions;
}