package com.example.a108590058_hw41;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private int mCount=0;
    private TextView TotalCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TotalCount = (TextView) findViewById(R.id.text_count);
        Log.d(LOG_TAG, "-------");
        Log.d(LOG_TAG, "onCreate");
        if (savedInstanceState !=null){
            String text=savedInstanceState.getString("reply_text");
            TotalCount.setText(text);
            mCount = Integer.parseInt(text);
        }
    }

    public void CountUp(View view) {
        Log.d(LOG_TAG, "Button clicked!");
        mCount++;
        if (TotalCount != null)
            TotalCount.setText(Integer.toString(mCount));
    }


    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(LOG_TAG, "onSaveInstanceState");
        outState.putString("reply_text",TotalCount.getText().toString());

    }
}