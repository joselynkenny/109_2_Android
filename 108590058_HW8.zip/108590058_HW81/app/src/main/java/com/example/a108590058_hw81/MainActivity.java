package com.example.a108590058_hw81;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView image;
    private int clicks = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = findViewById(R.id.battery_image);
        image.setImageLevel(clicks);
    }

    public void BatterySub(View view) {
        if (clicks > 0) {
            clicks--;
            image.setImageLevel(clicks);
        }
    }
    public void BatteryAdd(View view) {
        if (clicks < 6){
            clicks ++;
            image.setImageLevel(clicks);
        }
    }
}