package com.example.hw_61;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private String output= "Toppings: ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
    public void ShowToastButton(View view){
        displayToast(output);
    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((CheckBox) view).isChecked();
        // Check which radio button was clicked.

        switch (view.getId()) {
            case R.id.checkBox:
                output+=getString(R.string.s1)+" ";
                break;
            case R.id.checkBox2:
                output+=getString(R.string.s2)+" ";
                break;
            case R.id.checkBox3:
                output+=getString(R.string.s3)+" ";
                break;
             case R.id.checkBox4:
                 output+=getString(R.string.s4)+" ";
                break;
            case R.id.checkBox5:
                output+=getString(R.string.s5)+" ";
                break;
            default:
                // Do nothing.
                break;
        }
    }
}