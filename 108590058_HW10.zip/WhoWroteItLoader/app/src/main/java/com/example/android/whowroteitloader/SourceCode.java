package com.example.android.whowroteitloader;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;


public class SourceCode extends AsyncTaskLoader<String> {

    private Context mContext;
    private String mTransferProtocol;
    private String mQueryString;

    public SourceCode(@NonNull Context context, String queryString, String transferProtocol) {
        super(context);
        mContext=context;
        mTransferProtocol=transferProtocol;
        mQueryString=queryString;
    }

    @Nullable
    @Override
    public String loadInBackground() {
        return NetworkUtils.GetSourceCode(mContext,mQueryString,mTransferProtocol);
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }
}


